#include <bits/stdc++.h>

using namespace std;

int main() {
	
	int N, M;
	vector<int> V(1001);

	cin >> N >> M;
	
	for (int i = 0; i < N; i++) {
		int t;
		cin >> t;
		V[t] += 1;
	}
	for (int i = 0; i < M; i++) {
		int t;
		cin >> t;
		V[t] += 1;
	}
	for (int i = 0; i < 1001; i++) {
		if (V[i] == 1) cout << i << " ";
	}
}
