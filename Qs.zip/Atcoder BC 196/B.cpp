#include <bits/stdc++.h>

using namespace std;

int main() {
	
	string S;
	cin >> S;
	
	long long unsigned int i = 0;
	while (S[i] != '.' && i < S.size()) {
		cout << S[i];
		i++;
	}
	
}

