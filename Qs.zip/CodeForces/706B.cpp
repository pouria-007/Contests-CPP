#include <bits/stdc++.h>

using namespace std;
typedef long long unsigned int llui;

int main() {
	
	int N;
	cin >> N;
	
	vector<int> V(N);
	
	for (int i = 0; i < N; i++) {
		int temp;
		cin >> temp;
		V[i] = temp;
	}
	sort(V.begin(), V.end());
	
	int Q;
	cin >> Q;
	
	for (int i = 0; i<Q; i++) {
		int temp, ans;
		bool R = false;
		cin >> temp;
		if (temp >= V.back()) cout << N << "\n";
		else if (temp < V[0]) cout << 0 << "\n";
		else {
			R = true;
			int l=0, r=V.size();
			while (l <= r) {
				int mid = l + (r-l)/2;
				if (V[mid] <= temp) {
					ans = mid;
					l = mid+1;
				}
				else {
					r = mid-1;
				}
			}
		}
		 
		if(R) cout << ans+1 << "\n";
	}
	
}
