#include <bits/stdc++.h>

using namespace std;

vector<int> V;
vector<bool> visit;

void Dfs(int S) {
	
	if (visit[S]) {cout << (S + 1) << " "; return;}
	
	visit[S] = true;
	
	Dfs(V[S]);
	
	}


int main() {
	
	int N;
	cin >> N;
	
	V.resize(N);
	visit.resize(N);
	
	for (int i = 0; i < N; i++) {
		int A;
		cin >> A;
		
		V[i] = A - 1;
	}
	
	for (int i = 0; i < N; i++) {
		for(int j=0; j<N; j++) visit[j] = false;
		
		Dfs(i);
	}
	
}
