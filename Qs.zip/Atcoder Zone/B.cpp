#include <bits/stdc++.h>
#include <vector>

using namespace std;

int main() {
	
	double N, D, H; 
	cin >> N >> D >> H;
	
	vector<double> V(N);
	
	for (int i = 0; i < N; i++) {
		
		double x, y;
		cin >> x >> y;
		
		double m = (H - y) / (D - x);
		double t = H - (m * D); 
		
		V[i] = t;
	}
	
	sort(V.begin(), V.end(), greater<double>());
	
	if (V[0] > 0) { cout << V[0]; }
	else { cout << 0; }
	
}
