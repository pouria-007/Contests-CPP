//
//
// I DON'T GET THE QUESTION ???
//
//
//

#include <bits/stdc++.h>
#include <vector>

using namespace std;

int main() {
	
	int N;
	cin >> N;
	
	vector<long long int> A(N), B(N), C(N), D(N), E(N), V(5);
	vector<long long int> Ac(3), Bc(3), Cc(3), Dc(3), Ec(3);
	vector<pair<long long int, int>> M(N);
	
	for (int i = 0; i < N; i++) {
		
		long long int a, b, c, d, e;
		cin >> a >> b >> c >> d >> e;
		
		A[i] = a;
		B[i] = b;
		C[i] = c;
		D[i] = d;
		E[i] = e;
		
		M[i] = {(a+b+c+d+e), (i + 1)};
		
	}
	
	sort(M.begin(), M.end());
	
	for (int i = 0; i < 3; i++) {
		Ac[i] = A[M[N - i - 1].second];
		Bc[i] = B[M[N - i - 1].second];
		Cc[i] = C[M[N - i - 1].second];
		Dc[i] = D[M[N - i - 1].second];
		Ec[i] = E[M[N - i - 1].second];
	}
	
	sort(Ac.begin(), Ac.end(), greater<int>());
	sort(Bc.begin(), Bc.end(), greater<int>());
	sort(Cc.begin(), Cc.end(), greater<int>());
	sort(Dc.begin(), Dc.end(), greater<int>());
	sort(Ec.begin(), Ec.end(), greater<int>());
	
	V[0] = Ac[0];
	V[1] = Bc[0];
	V[2] = Cc[0];
	V[3] = Dc[0];
	V[4] = Ec[0];
 
	sort(V.begin(), V.end());
	
	cout << V[0];
}
