#include <bits/stdc++.h>
#include <string>
#include <queue>

using namespace std;

int main() {
	
	string ans = ""; 
	string S;
	cin >> S;
	bool R = false;
	deque<char> Rans;
	
	// Check for R and not R
	for (long long unsigned int i = 0; i < S.length(); i++) {
		
		if (S[i] == 'R') {
			if(!R) {R = true;}
			else if(R) {R = false; }
			continue;
		}
		else if (R) {
			Rans.push_front(S[i]);	
		}
		else {
			Rans.push_back(S[i]);
		}
	}
	
	if (R == true) { reverse(Rans.begin(), Rans.end()); }
	
	for (long long unsigned int i = 0; i < Rans.size(); i++) {
		// Remove Same pairs 
		if (ans.back() == Rans[i]) {
			ans.pop_back();
		}
		else {
			ans.push_back(Rans[i]);
		}
	}
	
	cout << ans;
}
