#include <bits/stdc++.h>
#include <string>

using namespace std;

int main() {
	
	int ans = 0;
	string S;
	cin >> S;
	
	for (long long unsigned int i = 0; i < S.length() - 3; i++) {
		
		string str(1, S[i]);
		str += S[i+1];
		str += S[i+2];
		str += S[i+3];
		if (str == "ZONe") {
			ans++;
		}
		
	}
	
	cout << ans;
}
