#include <bits/stdc++.h>

using namespace std;

int main() {
	
	int N;
	cin >> N;
	
	int ans = N - 1;
	cout << ans;
}
