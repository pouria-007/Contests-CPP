// Competitive Programmer's Handbook
// Chapter 1

// This contains <iostream vector algorithm ...>
#include <bits/stdc++.h>

using namespace std;

int main () {
	
	//If amount of input is Unknown :
	//This reads input until there is no more.
	int x;
	while (cin >> x) {
		//code
	}
	
	
	//Integers :
	int u; //32 bit 2*10^9
	long long y = 5LL; //64 bit 9*10^18
	
	//Tip: (a+b)%m = a%m + b%m
	//if x%m is negative, do +m
	
	
	//Floating point numbers :
	//classic cout
	printf("%.9f\n", x);
	//BUG
	double x = 0.3*3+0.1;
	printf("%.20f\n", x); // 0.99999999999999988898
	//FIX
	if (abs(a-b) < 1e-9) { // 1e-9 = 10^-9
		// a and b are equal
	}
	
	
	
	//Sortening code
	typedef long long ll;
	typedef vector<int> vi;
	typedef pair<int, int> pi;
	ll a = 123LL;
	
	//Macros
	#define F first
	#define REP(i,a,b) for (int i = a; i<=b; i++)
	#define SQ(a) a*a
	#define PB push_back
	v.PB(0);
	int x = SQ(3 + 3);
	
	
	//
	//MATHEMATICS
	//
	
	1+2+3+...+n = n (n-1) / 2
	(1^2)+(2^2)+...+(n ^2) = n (n+1) (2n+1) / 6 
	
	//Arithmetic progression
	//Donbale hesabi
	A1 + A2 + ... + An = n (A1+An) / 2
	//Geometric progression
	a + ak + ak^2 + ... + b = (bk-a) / (k-1) 
	//Harmonic Sum
	// ???
	
	//Number of subsets
	2^|S|
	
	 
	
	
}

















