//No fucking way ...
//
#include <bits/stdc++.h>

using namespace std;

int main() {
	
	int N;
	cin >> N;
	
	vector<int> V(N);
	
	for (int i = 0; i < N; i++) {
		int tmp;
		cin >> tmp;
		V[i] = tmp;
	}
	
}
