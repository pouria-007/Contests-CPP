#include <bits/stdc++.h>

using namespace std;

vector<bool> V(pow(10, 18)+1);
vector<long long> ans;

int main() {
	
	
	
}

