#include <bits/stdc++.h>

using namespace std;

int main() {
	
	double A, B;
	cin >> A >> B;
	
	cout << B*A/100;
	
}
